window.CMS = {
  SUPABASE_URL: "",        // ใส่ URL จาก Supabase
  SUPABASE_ANON_KEY: "",   // ใส่ anon key
  BUCKET: "properties"     // ชื่อ bucket เก็บรูป
};
