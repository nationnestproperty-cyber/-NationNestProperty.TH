window.STATIONS = [
  {
    "name": "BTS สยาม",
    "lat": 13.7456,
    "lng": 100.5347,
    "line": "BTS Sukhumvit/Silom"
  },
  {
    "name": "BTS อโศก",
    "lat": 13.7377,
    "lng": 100.5611,
    "line": "BTS Sukhumvit"
  },
  {
    "name": "MRT สุขุมวิท",
    "lat": 13.7372,
    "lng": 100.5619,
    "line": "MRT Blue"
  },
  {
    "name": "BTS พร้อมพงษ์",
    "lat": 13.73,
    "lng": 100.5696,
    "line": "BTS Sukhumvit"
  },
  {
    "name": "BTS ทองหล่อ",
    "lat": 13.7247,
    "lng": 100.578,
    "line": "BTS Sukhumvit"
  },
  {
    "name": "BTS เอกมัย",
    "lat": 13.7198,
    "lng": 100.5848,
    "line": "BTS Sukhumvit"
  },
  {
    "name": "BTS บางนา",
    "lat": 13.6682,
    "lng": 100.6068,
    "line": "BTS Sukhumvit"
  },
  {
    "name": "MRT พระราม 9",
    "lat": 13.7579,
    "lng": 100.5651,
    "line": "MRT Blue"
  },
  {
    "name": "MRT ห้วยขวาง",
    "lat": 13.776,
    "lng": 100.5733,
    "line": "MRT Blue"
  },
  {
    "name": "BTS หมอชิต",
    "lat": 13.802,
    "lng": 100.5535,
    "line": "BTS Sukhumvit"
  },
  {
    "name": "BTS สนามกีฬาแห่งชาติ",
    "lat": 13.7463,
    "lng": 100.5294,
    "line": "BTS Silom"
  },
  {
    "name": "BTS บางหว้า",
    "lat": 13.7207,
    "lng": 100.4589,
    "line": "BTS Silom"
  }
]