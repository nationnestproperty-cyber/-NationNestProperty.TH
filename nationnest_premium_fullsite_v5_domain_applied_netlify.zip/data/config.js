window.CONFIG = {
  "siteName": "NationNest Property",
  "slogan": "บริการครบวงจร ดูแลตั้งแต่หา–ปิด–โอน",
  "contactEmail": "admin@nationnestproperty.com",
  "phone": "0800000000",
  "lineUrl": "https://line.me/ti/p/~yourlineid",
  "videoUrl": "",
  "googleAppsScript": "",
  "mapboxToken": "",
  "orsToken": "",
  "leadsCsvUrl": ""
}